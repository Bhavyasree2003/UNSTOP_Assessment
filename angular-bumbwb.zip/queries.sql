-- Create the seats table
CREATE TABLE seats (
    seat_id INT AUTO_INCREMENT PRIMARY KEY,
    row_num INT NOT NULL,  -- Changed name to avoid reserved word conflict
    seat_position INT NOT NULL,
    status ENUM('available', 'reserved') NOT NULL
);

-- Create the reservations table
CREATE TABLE reservations (
    reservation_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(255) NOT NULL,
    customer_email VARCHAR(255) NOT NULL,
    seats_reserved TEXT NOT NULL, -- Stores seat IDs as a comma-separated string
    reservation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert sample data into the seats table
INSERT INTO seats (row_num, seat_position, status) VALUES
(1, 1, 'available'),
(1, 2, 'available'),
(1, 3, 'reserved'),
(2, 1, 'available'),
(2, 2, 'available'),
(2, 3, 'available'),
(3, 1, 'available'),
(3, 2, 'reserved'),
(3, 3, 'available');

-- Insert sample data into the reservations table
INSERT INTO reservations (customer_name, customer_email, seats_reserved) VALUES
('John Doe', 'john.doe@example.com', '1,2'),
('Jane Smith', 'jane.smith@example.com', '3'),
('Alice Johnson', 'alice.johnson@example.com', '4,5,6');

SHOW TABLES;
DESCRIBE seats;
DESCRIBE reservations;
