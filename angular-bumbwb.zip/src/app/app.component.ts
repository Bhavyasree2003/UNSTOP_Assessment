import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  seats: string[][] = []; // 2D array to represent seats
  totalRows: number = 12;
  seatsPerRow: number = 7;
  requestedSeats: number = 0; // Number of seats requested by the user
  successMessage: string = ''; // Message to indicate booking status

  constructor() {
    this.initializeSeats();
  }

  // Function to initialize seats with default availability
  initializeSeats() {
    // Initialize all seats
    for (let i = 0; i < this.totalRows; i++) {
      const row: string[] = [];
      for (let j = 0; j < (i === this.totalRows - 1 ? 3 : this.seatsPerRow); j++) {
        // Randomly mark some seats as 'reserved' to simulate pre-booked seats
        const isReserved = Math.random() < 0.3; // 30% chance a seat is already reserved
        row.push(isReserved ? 'reserved' : 'available');
      }
      this.seats.push(row);
    }
  }

  // Function to book seats
  bookSeats(requestedSeats: number) {
    this.successMessage = ''; // Clear any previous success message

    if (requestedSeats <= 0 || requestedSeats > this.getAvailableSeats()) {
      alert(`Please request between 1 and ${this.getAvailableSeats()} seats.`);
      return;
    }

    let seatsBooked = 0;
    for (let i = 0; i < this.seats.length && seatsBooked < requestedSeats; i++) {
      let row = this.seats[i];
      let availableSeatsInRow = row.filter(seat => seat === 'available').length;

      if (availableSeatsInRow >= requestedSeats - seatsBooked) {
        // Book the required number of seats in this row
        for (let j = 0; j < row.length && seatsBooked < requestedSeats; j++) {
          if (row[j] === 'available') {
            row[j] = 'my-reserved'; // Mark as reserved by the current user
            seatsBooked++;
          }
        }
        break;
      }
    }

    if (seatsBooked < requestedSeats) {
      alert('Not enough seats available in a single row. Booking nearby seats...');
      this.bookNearbySeats(requestedSeats - seatsBooked);
    }

    if (seatsBooked === requestedSeats) {
      this.successMessage = `Successfully booked ${requestedSeats} seat(s).`;
    }
  }

  // Function to book nearby seats if enough are not available in one row
  bookNearbySeats(seatsToBook: number) {
    let seatsBooked = 0;

    for (let i = 0; i < this.seats.length && seatsBooked < seatsToBook; i++) {
      for (let j = 0; j < this.seats[i].length && seatsBooked < seatsToBook; j++) {
        if (this.seats[i][j] === 'available') {
          this.seats[i][j] = 'my-reserved'; // Mark as reserved by the current user
          seatsBooked++;
        }
      }
    }

    if (seatsBooked < seatsToBook) {
      alert('Sorry, not enough seats available to fulfill your request.');
    } else {
      this.successMessage = `Successfully booked ${seatsToBook} seat(s).`;
    }
  }

  // Function to get the number of available seats
  getAvailableSeats(): number {
    return this.seats.flat().filter(seat => seat === 'available').length;
  }
}
