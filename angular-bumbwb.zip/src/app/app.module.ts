// app.module.ts
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';

@NgModule({
  declarations: [
    AppComponent // Declare the root component
  ],
  imports: [
    BrowserModule,
    FormsModule // Import FormsModule to use [(ngModel)] for two-way data binding
  ],
  providers: [],
  bootstrap: [AppComponent] // Bootstrapping the AppComponent
})
export class AppModule { }
