/***************************************************************************************************
 * BROWSER POLYFILLS
 */

/** IE9, IE10 and IE11 requires all of the following polyfills. **/
import 'core-js/es/array'; // Array methods
import 'core-js/es/array/from'; // Array.from method
import 'core-js/es/array/is-array'; // Array.isArray method
import 'core-js/es/array/of'; // Array.of method
import 'core-js/es/array/includes'; // Array.includes method
import 'core-js/es/object'; // Object methods
import 'core-js/es/object/assign'; // Object.assign method
import 'core-js/es/object/entries'; // Object.entries method
import 'core-js/es/object/keys'; // Object.keys method
import 'core-js/es/number'; // Number methods
import 'core-js/es/promise'; // Promise methods
import 'core-js/es/string'; // String methods
import 'core-js/es/symbol'; // Symbol methods
import 'core-js/es/reflect'; // Reflect methods

// If you need to support older browsers like IE9-11
import 'classlist.js'; // Add support for classList in older browsers
import 'web-animations-js'; // Add support for web animations

// For Angular to support older browsers
import 'zone.js'; // Included with Angular CLI

/***************************************************************************************************
 * Zone JS is required by Angular itself.
 */
import 'zone.js/dist/zone'; // Included with Angular CLI

/***************************************************************************************************
 * APPLICATION IMPORTS
 */
// Your application-specific imports go here, if any
